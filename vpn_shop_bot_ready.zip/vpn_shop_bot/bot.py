import os
import sqlite3
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters
)

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "285501640"))
CARD_NUMBER = os.getenv("CARD_NUMBER", "")
CARD_OWNER = os.getenv("CARD_OWNER", "")
BANK_NAME = os.getenv("BANK_NAME", "")
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "YourSupportUsername")

DB = "shop.db"

PLANS = {
    "1": {"name": "یک ماهه", "days": 30, "price": 100000},
    "3": {"name": "سه ماهه", "days": 90, "price": 250000},
    "6": {"name": "شش ماهه", "days": 180, "price": 400000},
    "12": {"name": "یک ساله", "days": 365, "price": 700000},
}

def db():
    return sqlite3.connect(DB)

def init_db():
    con = db()
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS configs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        config TEXT NOT NULL UNIQUE,
        status TEXT NOT NULL DEFAULT 'available',
        sold_to INTEGER,
        sold_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        username TEXT,
        plan_id TEXT NOT NULL,
        price INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'waiting_payment',
        receipt_file_id TEXT,
        config_id INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    con.commit()
    con.close()

def create_order(user_id, username, plan_id):
    con = db(); cur = con.cursor()
    cur.execute("INSERT INTO orders(user_id,username,plan_id,price) VALUES(?,?,?,?)",
                (user_id, username, plan_id, PLANS[plan_id]["price"]))
    oid = cur.lastrowid
    con.commit(); con.close()
    return oid

def get_order(oid):
    con = db(); cur = con.cursor()
    cur.execute("SELECT * FROM orders WHERE id=?", (oid,))
    row = cur.fetchone()
    con.close()
    return row

def set_receipt(oid, file_id):
    con = db(); cur = con.cursor()
    cur.execute("UPDATE orders SET receipt_file_id=?,status='waiting_approval' WHERE id=? AND status='waiting_payment'",
                (file_id, oid))
    con.commit(); con.close()

def available_config_count():
    con = db(); cur = con.cursor()
    cur.execute("SELECT COUNT(*) FROM configs WHERE status='available'")
    n = cur.fetchone()[0]
    con.close()
    return n

def reserve_config(oid, user_id):
    con = db(); cur = con.cursor()
    cur.execute("SELECT id,config FROM configs WHERE status='available' ORDER BY id LIMIT 1")
    row = cur.fetchone()
    if not row:
        con.close()
        return None
    cid, config = row
    cur.execute("UPDATE configs SET status='sold',sold_to=? WHERE id=? AND status='available'",
                (user_id, cid))
    cur.execute("UPDATE orders SET status='paid',config_id=? WHERE id=? AND status='waiting_approval'",
                (cid, oid))
    con.commit(); con.close()
    return cid, config

def reject_order(oid):
    con = db(); cur = con.cursor()
    cur.execute("UPDATE orders SET status='rejected' WHERE id=? AND status='waiting_approval'", (oid,))
    con.commit(); con.close()

def add_config(config):
    con = db(); cur = con.cursor()
    try:
        cur.execute("INSERT INTO configs(config) VALUES(?)", (config.strip(),))
        con.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        con.close()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = [
        [InlineKeyboardButton("🛒 خرید VPN", callback_data="plans")],
        [InlineKeyboardButton("📦 موجودی", callback_data="stock")],
        [InlineKeyboardButton("📱 خریدهای من", callback_data="mine")],
        [InlineKeyboardButton("☎️ پشتیبانی", callback_data="support")]
    ]
    await update.message.reply_text(
        "سلام 👋\nبه فروشگاه VPN خوش آمدید.",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def plans(update, context):
    q = update.callback_query; await q.answer()
    kb = [[InlineKeyboardButton(
        f"{p['name']} | {p['price']:,} تومان",
        callback_data=f"buy:{pid}"
    )] for pid,p in PLANS.items()]
    await q.edit_message_text("پلن را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(kb))

async def buy(update, context):
    q = update.callback_query; await q.answer()
    pid = q.data.split(":")[1]
    if available_config_count() < 1:
        await q.edit_message_text("❌ فعلاً موجودی کانفیگ نداریم.")
        return
    p = PLANS[pid]
    oid = create_order(q.from_user.id, q.from_user.username or "", pid)
    await q.edit_message_text(
        f"🧾 سفارش #{oid}\n\n"
        f"پلن: {p['name']}\nمدت: {p['days']} روز\n"
        f"مبلغ: {p['price']:,} تومان\n\n"
        f"🏦 بانک: {BANK_NAME}\n"
        f"💳 شماره کارت: `{CARD_NUMBER}`\n"
        f"👤 به نام: {CARD_OWNER}\n\n"
        "پس از کارت‌به‌کارت، عکس رسید را همینجا بفرست.",
        parse_mode="Markdown"
    )

async def receipt(update: Update, context):
    uid = update.effective_user.id
    con = db(); cur = con.cursor()
    cur.execute("""SELECT id FROM orders WHERE user_id=? AND status='waiting_payment'
                   ORDER BY id DESC LIMIT 1""", (uid,))
    row = cur.fetchone(); con.close()
    if not row:
        await update.message.reply_text("❌ سفارش در انتظار رسید پیدا نشد. ابتدا خرید را شروع کنید.")
        return
    oid = row[0]
    fid = update.message.photo[-1].file_id
    set_receipt(oid, fid)
    order = get_order(oid)
    p = PLANS[order[3]]
    kb = [[
        InlineKeyboardButton("✅ تأیید", callback_data=f"approve:{oid}"),
        InlineKeyboardButton("❌ رد", callback_data=f"reject:{oid}")
    ]]
    await context.bot.send_photo(
        ADMIN_ID, fid,
        caption=(f"🧾 رسید سفارش #{oid}\n"
                 f"کاربر: @{order[2] or 'ندارد'}\n"
                 f"Telegram ID: {order[1]}\n"
                 f"پلن: {p['name']}\nمبلغ: {order[4]:,} تومان"),
        reply_markup=InlineKeyboardMarkup(kb)
    )
    await update.message.reply_text("✅ رسید دریافت شد و برای بررسی ادمین ارسال شد.")

async def approve(update, context):
    q = update.callback_query
    if q.from_user.id != ADMIN_ID:
        await q.answer("دسترسی ندارید.", show_alert=True); return
    await q.answer()
    oid = int(q.data.split(":")[1])
    order = get_order(oid)
    if not order or order[5] != "waiting_approval":
        await q.edit_message_caption(caption="⚠️ سفارش معتبر نیست یا قبلاً پردازش شده.")
        return
    result = reserve_config(oid, order[1])
    if not result:
        await q.edit_message_caption(caption="❌ موجودی کانفیگ تمام شده است.")
        return
    cid, config = result
    await context.bot.send_message(
        order[1],
        f"✅ پرداخت تأیید شد!\n\n"
        f"📦 پلن: {PLANS[order[3]]['name']}\n"
        "🔐 کانفیگ شما:\n\n"
        f"`{config}`\n\n"
        "این کانفیگ اختصاصی سفارش شماست.",
        parse_mode="Markdown"
    )
    await q.edit_message_caption(caption=f"✅ سفارش #{oid} تأیید و کانفیگ شماره {cid} تحویل شد.")

async def reject(update, context):
    q = update.callback_query
    if q.from_user.id != ADMIN_ID:
        await q.answer("دسترسی ندارید.", show_alert=True); return
    await q.answer()
    oid = int(q.data.split(":")[1])
    order = get_order(oid)
    if not order:
        await q.edit_message_caption(caption="❌ سفارش پیدا نشد."); return
    reject_order(oid)
    await context.bot.send_message(order[1], f"❌ رسید سفارش #{oid} تأیید نشد.\nدر صورت نیاز با پشتیبانی تماس بگیرید.")
    await q.edit_message_caption(caption=f"❌ سفارش #{oid} رد شد.")

async def admin(update, context):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("⛔ دسترسی ندارید."); return
    await update.message.reply_text(
        f"👨‍💻 پنل ادمین\n\nموجودی: {available_config_count()}\n\n"
        "برای افزودن کانفیگ، فقط متن vless://... را در همین چت برای ربات بفرست."
    )

async def text_admin(update, context):
    if update.effective_user.id != ADMIN_ID:
        return
    text = (update.message.text or "").strip()
    if text.startswith(("vless://", "vmess://", "trojan://", "ss://")):
        ok = add_config(text)
        await update.message.reply_text("✅ کانفیگ به موجودی اضافه شد." if ok else "⚠️ این کانفیگ قبلاً ثبت شده.")
    else:
        await update.message.reply_text("برای افزودن موجودی، یک لینک vless://... ارسال کن.")

async def buttons(update, context):
    q = update.callback_query
    if q.data == "plans": await plans(update, context)
    elif q.data.startswith("buy:"): await buy(update, context)
    elif q.data.startswith("approve:"): await approve(update, context)
    elif q.data.startswith("reject:"): await reject(update, context)
    elif q.data == "stock":
        await q.answer()
        await q.edit_message_text(f"📦 موجودی فعلی: {available_config_count()} کانفیگ")
    elif q.data == "support":
        await q.answer()
        await q.edit_message_text(f"☎️ پشتیبانی: @{SUPPORT_USERNAME}")
    elif q.data == "mine":
        await q.answer()
        await q.edit_message_text("📱 خریدهای قبلی در نسخه اولیه نمایش داده نمی‌شوند.")

def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN در .env تنظیم نشده است")
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CallbackQueryHandler(buttons))
    app.add_handler(MessageHandler(filters.PHOTO, receipt))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_admin))
    print("VPN Shop Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
